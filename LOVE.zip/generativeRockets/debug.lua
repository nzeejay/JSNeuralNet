local ret = {
    debug = false,
    frameRate = 0,
}

return ret;