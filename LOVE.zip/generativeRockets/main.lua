settings = require('settings');
debug = require('debug');

function love.load()
    factories = {};

    factories.player = require('playerRocket');
    factories.level = require('levelLoader');

    start();
end

function start()
    ents = {};
    level = {};

    file = love.filesystem.newFile("levels/level1.txt")
    file:open('r')
    local s = file:read()
    file:close()

    ents.player = factories.player.new(100, 100);

    level = factories.level.new(s, ents.player);

    
    local ctrls = require('menus/controls');

    
    local callback = {func = "", args = ""};
    ents.newGame = ctrls.button({x = 20, y = 20}, {x = 120, y = 40}, "New Game", {x = 2, y = 2}, callback);
    ents.newGame.callback = {func = function(args) args.a.text = args.b end, args = {a = ents.newGame, b = "Clicked!"}};
end

function love.update(dt)

    ents.player:update(dt);
    ents.newGame:update(dt);
    level:update(dt);

    udt = dt;

end

function love.draw()
    ents.player:draw();
    ents.newGame:draw();
    level:draw();
love.graphics.print("       " .. 1 / udt);
end