ret = {
    rotateSpeed = 12,
    quality = 5,
    gravity = 150,
}

return ret;