local ret = {};

local ctrls = require('controls');

ret.newGame = ctrls.button({x = 20, y = 20}, {x = 80, y = 40}, "New Game");