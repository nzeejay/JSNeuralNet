local ret = {};

ret.canUpdate = false;
ret.canDraw = false;

ret.player = {};

ret.currentLevel = {};

ret.resetStr = "";

ret.changeLevel = function(self, level) 

    ret.resetStr = level;

    file = love.filesystem.newFile("levels/" .. level .. ".txt");
    file:open('r');
    local str = file:read();
    file:close();

    self.player = factories.player.new(0, 0);

    self.currentLevel = factories.level.new(str, self.player);

    self.canUpdate = true;
    self.canDraw = true;
end

ret.reset = function(self) 
    self:changeLevel(self.resetStr);
end

ret.update = function(self, dt)
    if self.canUpdate then
        self.player:update(dt);
        self.currentLevel:update(dt);

        if love.keyboard.isDown("escape") then 
            level.canUpdate = false;
            menu:openNew("pause");
        end
    end
end

ret.draw = function(self)
    if self.canDraw then
        self.player:draw();
        self.currentLevel:draw();
        if not self.canUpdate then 
            love.graphics.push();
            love.graphics.setColor(0, 0, 0, 0.75); 
            love.graphics.rectangle("fill", 0, 0, love.graphics.getWidth(), love.graphics.getHeight());
            love.graphics.pop();
        end
    end
end

return ret;