local ret = {};

local ctrls = require('menus/controls');
local util = require('../utils');

ret.name = "pause";

ret.font = love.graphics.newFont(48);

ret.title = {text = love.graphics.newText(ret.font, "Paused"), 
angle = 0, angleCount = 0,
scale = 0.5, scaleCount = 0,
clr = {}, clrCount = 0};


ret.buttons = {
    newGame = ctrls.button({x = 300, y = 220}, {x = 500, y = 260}, "Resume", 24, {func = function(args) level.canUpdate = true; menu:reset(); end}),
    menu = ctrls.button({x = 300, y = 270}, {x = 500, y = 310}, "Main menu", 24, {
        func = function(args) 
            level.canUpdate = false; 
            level.canDraw = false; 
            menu:reset();
            menu:openNew("main");
        end
    }),
    quit = ctrls.button({x = 300, y = 320}, {x = 500, y = 360}, "Quit", 24, {func = function(args) love.event.quit() end})
};

ret.update = function(self, dt)
    
    self.title.angleCount = (self.title.angleCount + 2.2 * dt) % (math.pi * 2);
    self.title.angle = math.sin(self.title.angleCount) * 0.35;

    self.title.scaleCount = (self.title.scaleCount + 1.5 * dt) % (math.pi * 2);
    self.title.scale = math.sin(self.title.scaleCount) / 4 + 1;

    self.title.clrCount = (self.title.clrCount + 100 * dt) % 255;
    self.title.clr = util.clr.HSL(self.title.clrCount, 255, 255/2, 255);


    for key, val in pairs(self.buttons) do
        val:update();
    end
end



ret.draw = function(self)
    love.graphics.push();
    love.graphics.setColor(self.title.clr.r/255, self.title.clr.g/255, self.title.clr.b/255);
    love.graphics.draw(self.title.text, 400, 90, self.title.angle, 
                       self.title.scale, self.title.scale,
                       self.title.text:getWidth()/2, self.title.text:getHeight()/2);
    love.graphics.pop();
    for key, val in pairs(self.buttons) do
        val:draw();
    end
end

return ret;