local ret = {};

local ctrls = require('menus/controls');
local util = require('../utils');

ret.name = "levelSelect";

ret.buttons = {
    ctrls.button({x = 300, y = 220}, {x = 500, y = 260}, "1", 24, {func = function(args) level:changeLevel("1"); menu:reset() end}),
    --ctrls.button({x = 300, y = 270}, {x = 500, y = 310}, "2", 24, {func = function(args) level:changeLevel("2"); menu:reset() end}),
    --ctrls.button({x = 300, y = 320}, {x = 500, y = 360}, "3", 24, {func = function(args) level:changeLevel("3"); menu:reset() end}),
    --ctrls.button({x = 300, y = 370}, {x = 500, y = 410}, "4", 24, {func = function(args) level:changeLevel("4"); menu:reset() end}),
    ctrls.button({x = 300, y = 420}, {x = 500, y = 460}, "back", 24, {func = function(args) menu:back() end})
};

ret.update = function(self, dt)
    for key, val in pairs(self.buttons) do
        val:update();
    end
end

ret.draw = function(self)
    for key, val in pairs(self.buttons) do
        val:draw();
    end
end

return ret;