local ret = {}
    
    ret.menus = {
        main = require('menus/mainMenu'),
        levelSelect = require('menus/levelSelect'),
        
        pause = require('menus/pause');
        levelFail = require('menus/levelFail');

        levelComplete = require('menus/levelComplete');
    };

    ret.menuHistory = {
        index = 0,
        items = {}
    };

    ret.openNew = function (self, menuName)
        table.insert(self.menuHistory.items, menuName);
        self.menuHistory.index = self.menuHistory.index + 1;
    end

    ret.back = function (self)
        table.remove(self.menuHistory.items);
        self.menuHistory.index = self.menuHistory.index - 1;
    end

    ret.reset = function(self)   
        self.menuHistory = {
            index = 0;
            items = {};
        }
    end

    ret.update = function(self, dt)
        local currentMenu = self.menuHistory.items[self.menuHistory.index];
        
        for key, val in pairs(self.menus) do
            if currentMenu == val.name then val:update(dt); end
        end
    end

    ret.draw = function (self)
        local currentMenu = self.menuHistory.items[self.menuHistory.index];

        for key, val in pairs(self.menus) do
            if currentMenu == val.name then val:draw(); end
        end
    end

return ret;