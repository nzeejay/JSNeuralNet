local ret = {
    rotateSpeed = 10,
    quality = 5,
    gravity = 150,
}

return ret;