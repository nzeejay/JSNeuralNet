function love.load()
    settings = require('settings');
    dbg = require('debug');

    highscores = require('Highscores');
    
    factories = {};

    factories.player = require('playerRocket');
    factories.level = require('levelLoader');

    mouseClickable = true;

    start();
    love.window.setMode(800, 600, {vsync = true});
end

function start()

   menu = require('menuManager');
   menu:openNew("main");

   level = require('levelManager');
end

function love.update(dt)

    level:update(dt);
    menu:update(dt);

end

function love.draw()

    level:draw();
    menu:draw();

end