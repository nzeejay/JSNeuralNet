local ret = {};

local util = require('utils');

ret.addScore = function(self, score)

    local str = "level_1.txt";

    local file = io.open(str, "a+");

    io.output(file);

    io.write(score .. ";");

    io.close(file);
end

ret.loadScores = function()
    local str = "level_1.txt";

    local file = io.open(str, "r");
    local str = file:read "*a";
    file:close();

    local scores = util.str.explode(str, ";");

    table.remove(scores, table.getn(scores));

	
	table.sort(scores, function(a, b) return tonumber(a) < tonumber(b) end);
	
	return scores;

end

ret.getFour = function()
    local retu = {};
    local scores = ret.loadScores();
    retu[1] = scores[1];
    retu[2] = scores[2];
    retu[3] = scores[3];
    retu[4] = scores[4];

    return retu;
end

return ret;