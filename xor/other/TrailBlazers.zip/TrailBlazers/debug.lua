local dbg = {
    toggle = false,
    frameRate = 0,
}

return dbg;